const RestaurantDetail = {
    templateRestaurantDetail: `
        <div id="content" class="content">
            <detail-restaurant class="detail__restaurant"></detail-restaurant>
        </div>
    `,
};

export default RestaurantDetail;
