export default function SectContent(children) {
    return `
        <section id="sect-content" class="sect-content">
            ${children}
        </section>
    `;
}
